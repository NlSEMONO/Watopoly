#include "coop.h"

Coop::~Coop() {}

Coop::Coop(): Square{"Coop Fee"} {}
