#ifndef __COOP_H__
#define __COOP_H__

#include "square.h"

class Coop: public Square {
    public: 
        Coop();
        virtual ~Coop() override;
};

#endif
