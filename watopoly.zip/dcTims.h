#ifndef __DCTIMS_H__
#define __DCTIMS_H__
#include <vector>
#include <string>
#include "player.h"
#include "square.h"


class DcTims {
    std::string name = "DCTims";
    
};

#endif
