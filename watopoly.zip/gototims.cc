#include "gototims.h"

GoToTims::GoToTims(): Square{"Go To Tims"} {}

GoToTims::~GoToTims() {}
