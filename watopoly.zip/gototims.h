#ifndef __GOTOTIMS_H__
#define __GOTOTIMS_H__

#include "square.h"

class GoToTims : public Square {
    public: 
        GoToTims();
        virtual ~GoToTims() override;
        
};

#endif

