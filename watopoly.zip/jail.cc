#include "jail.h"

Jail::Jail(): Square{"DC Tims Line"} {}

Jail::~Jail() {}
