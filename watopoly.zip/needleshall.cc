#include "needleshall.h"

NeedlesHall::NeedlesHall(std::string name): Square{name} {}

NeedlesHall::~NeedlesHall() {}

