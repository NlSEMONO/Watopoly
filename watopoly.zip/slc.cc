#include "slc.h"
using namespace std;

SLC::SLC(string name): Square{name} {}

SLC::~SLC() {}
