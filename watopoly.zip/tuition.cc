#include "tuition.h"

Tuition::~Tuition() {}

Tuition::Tuition(): Square{"TUITION"} {}
