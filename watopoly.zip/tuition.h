#ifndef __TUITION_H__
#define __TUITION_H__

#include "square.h"

class Tuition: public Square {
    public:
        Tuition();
        virtual ~Tuition() override;
};

#endif
